# ============================================================
# DAY 1 - PART 2: Market Cap Calculator (Full Project)
# AI Engineering Bootcamp - Codebasics
# ============================================================
# WHAT YOU WILL LEARN:
#   - Applying OOP to a real-world problem
#   - Multi-level inheritance (Company -> TechCompany)
#   - Method chaining
#   - Working with collections of objects
#   - String formatting and number formatting
# ============================================================
# HOW TO RUN:
#   python day1_part2_market_cap.py
# ============================================================


# ============================================================
# CLASS 1: Company (Base Class)
# ============================================================

class Company:
    """
    Represents any publicly traded company.
    This is the BASE (parent) class.
    TechCompany will inherit from this.
    """

    # Class variable: shared across all Company objects
    # Used for currency conversion
    exchange_rate_usd_to_inr = 83.5

    def __init__(self, name, ticker, stock_price_usd, shares_outstanding_millions):
        """
        Constructor - called when you create a Company object.

        Parameters:
            name                      : Company name e.g. "Apple"
            ticker                    : Stock symbol e.g. "AAPL"
            stock_price_usd           : Current stock price in USD e.g. 189.0
            shares_outstanding_millions: Total shares in the market (in millions)
        """
        self.name = name
        self.ticker = ticker
        self.stock_price_usd = stock_price_usd
        self.shares_outstanding = shares_outstanding_millions

    def market_cap_usd(self):
        """
        Market Cap = Stock Price × Total Shares Outstanding
        Result is in MILLIONS of USD.

        Example: Apple
            Stock price = $189
            Shares = 15,500 million
            Market Cap = 189 × 15,500 = 2,929,500 million = ~$2.9 Trillion
        """
        return self.stock_price_usd * self.shares_outstanding

    def market_cap_inr(self):
        """
        Convert market cap from USD to INR.
        Uses the class variable exchange_rate_usd_to_inr.
        """
        return self.market_cap_usd() * self.exchange_rate_usd_to_inr

    def market_cap_label(self):
        """
        Format market cap into a readable label.
        - If >= 1 million million (1 trillion): show as T (Trillion)
        - If >= 1000 million (1 billion): show as B (Billion)
        - Otherwise: show as M (Million)
        """
        cap = self.market_cap_usd()

        if cap >= 1_000_000:    # 1 trillion = 1,000,000 million
            return f"${cap / 1_000_000:.2f}T"
        elif cap >= 1_000:      # 1 billion = 1,000 million
            return f"${cap / 1_000:.2f}B"
        else:
            return f"${cap:.2f}M"

    def __str__(self):
        """
        Called when you print() a Company object.
        Returns a nicely formatted box with company info.
        """
        return (
            f"{'=' * 45}\n"
            f"  {self.name} ({self.ticker})\n"
            f"  Stock Price : ${self.stock_price_usd:,.2f}\n"
            f"  Market Cap  : {self.market_cap_label()}\n"
            f"{'=' * 45}"
        )

    def __lt__(self, other):
        """
        __lt__ means "less than" (<)
        This enables Python's sort() to compare Company objects.

        Without this, sorted([company1, company2]) would fail.
        With this, Python knows HOW to compare two companies.
        """
        return self.market_cap_usd() < other.market_cap_usd()


# ============================================================
# CLASS 2: TechCompany (Child Class)
# ============================================================

class TechCompany(Company):
    """
    Extends Company with R&D (Research & Development) tracking.
    Tech companies invest heavily in R&D - it's a key metric.

    Inherits everything from Company and adds:
        - rd_spend: how much the company spends on R&D
        - rd_to_market_cap_ratio(): R&D as % of market cap
    """

    def __init__(self, name, ticker, stock_price_usd,
                 shares_outstanding_millions, rd_spend_millions):
        """
        Calls the parent (Company) constructor first,
        then adds rd_spend on top.
        """
        # Always call super().__init__() first!
        # This sets up name, ticker, stock_price_usd, shares_outstanding
        super().__init__(name, ticker, stock_price_usd, shares_outstanding_millions)

        # New property specific to TechCompany
        self.rd_spend = rd_spend_millions   # R&D spend in millions USD

    def rd_to_market_cap_ratio(self):
        """
        R&D Ratio = (R&D Spend / Market Cap) × 100
        Tells us what % of a company's market value goes into R&D.

        Higher ratio = company invests more in innovation relative to its size.
        """
        return (self.rd_spend / self.market_cap_usd()) * 100

    def __str__(self):
        """
        Override parent's __str__ to ADD R&D info.
        We call super().__str__() to get the base info,
        then we append R&D details.
        """
        base = super().__str__()   # Get parent's output

        # Add R&D lines before the last "====" line
        rd_info = (
            f"  R&D Spend   : ${self.rd_spend:,}M\n"
            f"  R&D Ratio   : {self.rd_to_market_cap_ratio():.4f}%\n"
            f"{'=' * 45}"
        )

        # Replace the last line (====) with our extended version
        return base.rsplit('\n', 1)[0] + '\n' + rd_info


# ============================================================
# CLASS 3: Portfolio (Collection Manager)
# ============================================================

class Portfolio:
    """
    Manages a collection of Company objects.
    Like a stock portfolio tracker.

    Key feature: method chaining
        portfolio.add(company1).add(company2).add(company3)
    This is possible because .add() returns 'self'.
    """

    def __init__(self, name):
        self.name = name
        self.companies = []   # Empty list to store Company objects

    def add(self, company):
        """
        Add a company to the portfolio.
        Returns 'self' to allow METHOD CHAINING:
            portfolio.add(apple).add(google).add(meta)
        Without 'return self', you'd have to write 3 separate lines.
        """
        self.companies.append(company)
        return self   # <-- This is what enables method chaining!

    def total_market_cap(self):
        """
        Sum of market caps of all companies.
        Uses a generator expression (memory-efficient loop).
        """
        return sum(c.market_cap_usd() for c in self.companies)

    def top_by_market_cap(self, n=3):
        """
        Return top N companies sorted by market cap (highest first).
        
        sorted() works because Company has __lt__ defined.
        reverse=True means largest first.
        [:n] means take first n items.
        """
        return sorted(self.companies, reverse=True)[:n]

    def display(self):
        """Print a full portfolio summary"""
        print(f"\n{'#' * 50}")
        print(f"  📊 Portfolio: {self.name}")
        print(f"  Total Market Cap: ${self.total_market_cap() / 1_000_000:.2f}T")
        print(f"{'#' * 50}")

        # Show top 3
        top_n = min(3, len(self.companies))
        print(f"\n🏆 Top {top_n} Companies by Market Cap:")
        for i, company in enumerate(self.top_by_market_cap(3), start=1):
            # enumerate with start=1 means i starts at 1 (not 0)
            print(f"   {i}. {company.name} ({company.ticker}): {company.market_cap_label()}")

        # Show all companies
        print(f"\n📋 All Companies:")
        for company in self.companies:
            print(company)
            print()   # blank line between companies


# ============================================================
# MAIN PROGRAM
# ============================================================

if __name__ == "__main__":
    # __name__ == "__main__" means:
    # "Only run this code if the file is run directly"
    # "Don't run this if this file is imported by another file"

    print("🚀 Market Cap Calculator - AI Engineering Bootcamp\n")

    # Create a portfolio of the "Magnificent 7" tech companies
    mag7 = Portfolio("Magnificent 7")

    # Method chaining - add all 7 companies in one expression
    # Each .add() returns the portfolio itself, so we can keep chaining
    mag7.add(TechCompany("Apple",     "AAPL", 189, 15500, 29000)) \
        .add(TechCompany("Microsoft", "MSFT", 378,  7430, 27000)) \
        .add(TechCompany("Google",    "GOOGL", 141, 12500, 45000)) \
        .add(TechCompany("Amazon",    "AMZN", 178, 10500, 85000)) \
        .add(TechCompany("NVIDIA",    "NVDA", 875,  2460,  8900)) \
        .add(TechCompany("Meta",      "META", 485,  2580, 35000)) \
        .add(TechCompany("Tesla",     "TSLA", 245,  3190,  3200))

    # Display the full portfolio
    mag7.display()

    # Extra: Show INR conversion for Apple
    apple = mag7.companies[0]
    print(f"\n💰 {apple.name} Market Cap in INR: "
          f"₹{apple.market_cap_inr() / 1_000_000:.2f}T")

    # Extra: Sort and show all companies by market cap
    print("\n📈 All Companies Ranked by Market Cap:")
    ranked = sorted(mag7.companies, reverse=True)
    for rank, company in enumerate(ranked, start=1):
        print(f"  #{rank} {company.name:12} {company.market_cap_label():>10}")
