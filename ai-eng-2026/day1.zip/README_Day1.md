# Day 1 - AI Engineering Bootcamp
## Files & Run Order

---

### 📦 Install Dependencies First
```bash
pip install fastapi uvicorn requests
```

---

### 📁 Files

| File | Topic | How to Run |
|------|-------|------------|
| `day1_part1_oop_basics.py` | OOP: Classes, Inheritance, Magic Methods | `python day1_part1_oop_basics.py` |
| `day1_part2_market_cap.py` | Project: Market Cap Calculator | `python day1_part2_market_cap.py` |
| `day1_part3_api_calls.py` | REST APIs: GitHub + LLM API calls | `python day1_part3_api_calls.py` |
| `day1_part4_fastapi_server.py` | FastAPI Server | `uvicorn day1_part4_fastapi_server:app --reload` |
| `day1_part5_test_api.py` | Testing the FastAPI server | `python day1_part5_test_api.py` |

---

### 🚀 Recommended Run Order

1. Run Part 1 → See OOP concepts in action
2. Run Part 2 → See the Market Cap project
3. Run Part 3 → See API calls (GitHub profile fetcher)
4. Start Part 4 server → Keep this running in a terminal
5. Run Part 5 in a NEW terminal → Tests all API endpoints

---

### 🌐 API Endpoints (after starting Part 4)

| Method | URL | Description |
|--------|-----|-------------|
| GET | http://127.0.0.1:8000/ | Root |
| GET | http://127.0.0.1:8000/health | Health check |
| POST | http://127.0.0.1:8000/company/analyze | Analyze a company |
| GET | http://127.0.0.1:8000/github/{username} | GitHub profile |
| GET | http://127.0.0.1:8000/companies/top?n=3 | Top N companies |
| GET | http://127.0.0.1:8000/companies/all | All companies |
| GET | http://127.0.0.1:8000/docs | 📖 Interactive API docs |

---

### 💡 Tips

- In Part 4, the `--reload` flag auto-restarts the server when you save changes
- Visit `/docs` in browser for a beautiful interactive UI to test your API
- Part 3's `call_openai()` requires a real API key - use the simulation function for now
- We'll use a **free Groq API key** starting Day 3!
