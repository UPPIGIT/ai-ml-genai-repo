# ============================================================
# DAY 1 - PART 3: Calling REST APIs with Python
# AI Engineering Bootcamp - Codebasics
# ============================================================
# WHAT YOU WILL LEARN:
#   - What REST APIs are and how they work
#   - HTTP methods: GET, POST
#   - HTTP status codes (200, 404, 429, 500)
#   - Calling public APIs (GitHub) - no key needed
#   - Calling LLM APIs (OpenAI format) - requires API key
#   - Error handling for API calls
# ============================================================
# HOW TO RUN:
#   pip install requests
#   python day1_part3_api_calls.py
# ============================================================

import requests   # Library for making HTTP calls
import json       # Library for working with JSON data


# ============================================================
# SECTION 1: Understanding REST APIs
# ============================================================
# REST API = a way for two programs to talk to each other over HTTP
#
# Flow:
#   Your Code ──── HTTP Request ───► API Server
#   Your Code ◄─── HTTP Response ── API Server
#
# HTTP Methods:
#   GET    → Read/fetch data      (like opening a webpage)
#   POST   → Send/create data     (like submitting a form)
#   PUT    → Update existing data
#   DELETE → Delete data
#
# HTTP Status Codes:
#   200 → OK (success)
#   201 → Created (POST was successful)
#   400 → Bad Request (you sent wrong data)
#   401 → Unauthorized (wrong API key)
#   404 → Not Found (resource doesn't exist)
#   429 → Too Many Requests (rate limit hit)
#   500 → Internal Server Error (their problem)


# ============================================================
# SECTION 2: Calling a Public API (GitHub)
# ============================================================
# GitHub API is FREE and doesn't need an API key for basic use.
# This is perfect for learning!

def get_github_user(username):
    """
    Fetch a GitHub user's public profile.
    
    Parameters:
        username: GitHub username (e.g. "torvalds", "gvanrossum")
    
    Returns:
        dict with user info, or error message
    """

    # Build the URL - GitHub API format: /users/{username}
    url = f"https://api.github.com/users/{username}"

    print(f"📡 Calling: {url}")

    # Make the GET request
    # requests.get() sends an HTTP GET request and waits for response
    response = requests.get(url)

    # Check the status code to know if it worked
    if response.status_code == 200:
        # .json() converts the response text to a Python dictionary
        data = response.json()

        # Extract only the fields we care about
        return {
            "name": data.get("name", "N/A"),           # .get() avoids KeyError if missing
            "username": data.get("login"),
            "public_repos": data.get("public_repos"),
            "followers": data.get("followers"),
            "following": data.get("following"),
            "bio": data.get("bio", "No bio"),
            "location": data.get("location", "Unknown"),
            "profile_url": data.get("html_url")
        }

    elif response.status_code == 404:
        return {"error": f"User '{username}' not found on GitHub"}

    elif response.status_code == 429:
        return {"error": "Rate limit exceeded. Wait a minute and try again."}

    else:
        return {"error": f"Unexpected error: {response.status_code}"}


def get_github_repos(username, limit=5):
    """
    Fetch a user's public repositories, sorted by stars.
    
    Parameters:
        username: GitHub username
        limit   : max number of repos to return (default 5)
    """

    # Query parameters: ?sort=stars&per_page=5
    # This is how you filter results in a GET request
    url = f"https://api.github.com/users/{username}/repos"
    params = {
        "sort": "stars",        # Sort by stars (most popular first)
        "per_page": limit,      # Limit results
        "direction": "desc"     # Descending order (highest first)
    }

    # params= automatically adds them to the URL as query parameters
    response = requests.get(url, params=params)

    if response.status_code == 200:
        repos = response.json()   # This is a LIST of repo objects

        # Extract key info from each repo
        return [
            {
                "name": repo["name"],
                "description": repo.get("description", "No description"),
                "stars": repo["stargazers_count"],
                "language": repo.get("language", "Unknown"),
                "url": repo["html_url"]
            }
            for repo in repos   # List comprehension = compact loop
        ]

    return {"error": f"Could not fetch repos: {response.status_code}"}


# ============================================================
# SECTION 3: Calling an LLM API
# ============================================================
# This shows HOW LLM APIs work under the hood.
# LangChain uses this same pattern internally.
#
# NOTE: To actually run call_openai(), you need a real API key.
# We'll use a free alternative (Groq) later in Day 3.

def call_openai(prompt, api_key, model="gpt-3.5-turbo"):
    """
    Call the OpenAI Chat Completions API.
    
    This is the RAW version - no LangChain, just plain HTTP.
    Understanding this helps you debug LangChain issues later.
    
    Parameters:
        prompt : The user's question/instruction
        api_key: Your OpenAI API key (starts with "sk-")
        model  : Which model to use (default: gpt-3.5-turbo)
    
    Returns:
        str: The model's response text
    """

    url = "https://api.openai.com/v1/chat/completions"

    # Headers tell the server:
    #   1. Authorization: your API key (like a password)
    #   2. Content-Type: we're sending JSON data
    headers = {
        "Authorization": f"Bearer {api_key}",  # Bearer = standard auth format
        "Content-Type": "application/json"
    }

    # The request body - what we're asking the model
    body = {
        "model": model,
        "messages": [
            # System message: sets the AI's behavior/personality
            {
                "role": "system",
                "content": "You are a helpful assistant for software engineers."
            },
            # User message: the actual question
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.7,    # 0 = consistent, 1 = creative
        "max_tokens": 500      # Max length of response
    }

    # POST request because we're SENDING data (not just reading)
    response = requests.post(url, headers=headers, json=body)

    if response.status_code == 200:
        data = response.json()
        # Navigate the response structure to get the actual text
        # data["choices"][0]["message"]["content"] is the standard path
        return data["choices"][0]["message"]["content"]

    elif response.status_code == 401:
        raise Exception("Invalid API key. Check your OpenAI key.")

    elif response.status_code == 429:
        raise Exception("Rate limit hit. Wait a moment and try again.")

    elif response.status_code == 400:
        raise Exception(f"Bad request: {response.json().get('error', {}).get('message')}")

    else:
        raise Exception(f"API Error {response.status_code}: {response.text}")


def simulate_llm_call(prompt):
    """
    Simulates an LLM response WITHOUT needing an API key.
    Just for understanding the structure and testing locally.
    """
    print(f"\n🤖 Simulated LLM Call")
    print(f"   Prompt: {prompt}")

    # This is what the real response structure looks like
    fake_response = {
        "id": "chatcmpl-abc123",
        "object": "chat.completion",
        "model": "gpt-3.5-turbo",
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": f"[SIMULATED] This is a response to: '{prompt}'"
                },
                "finish_reason": "stop"
            }
        ],
        "usage": {
            "prompt_tokens": 25,      # Tokens in your input
            "completion_tokens": 15,  # Tokens in the response
            "total_tokens": 40        # Total tokens used (you pay for this)
        }
    }

    # Extract just the text (this is exactly what call_openai() does)
    response_text = fake_response["choices"][0]["message"]["content"]
    tokens_used = fake_response["usage"]["total_tokens"]

    print(f"   Response: {response_text}")
    print(f"   Tokens used: {tokens_used}")
    return response_text


# ============================================================
# SECTION 4: Error Handling Best Practices
# ============================================================

def safe_api_call(url, params=None, headers=None):
    """
    A wrapper for API calls with proper error handling.
    Use this pattern in all your AI projects.
    """
    try:
        response = requests.get(url, params=params, headers=headers, timeout=10)
        # timeout=10 means: give up if no response in 10 seconds

        response.raise_for_status()  # Raises an exception for 4xx and 5xx codes
        return response.json()

    except requests.exceptions.Timeout:
        print("❌ Request timed out. Server is too slow.")
        return None

    except requests.exceptions.ConnectionError:
        print("❌ No internet connection or server is down.")
        return None

    except requests.exceptions.HTTPError as e:
        print(f"❌ HTTP Error: {e}")
        return None

    except requests.exceptions.JSONDecodeError:
        print("❌ Response was not valid JSON.")
        return None


# ============================================================
# MAIN PROGRAM
# ============================================================

if __name__ == "__main__":

    print("=" * 55)
    print("  DAY 1 - REST API Calls")
    print("=" * 55)

    # --- Test 1: GitHub User Profile ---
    print("\n📌 TEST 1: GitHub User Profile")
    print("-" * 40)

    user = get_github_user("torvalds")   # Linus Torvalds (Linux creator)
    if "error" not in user:
        print(f"Name       : {user['name']}")
        print(f"Username   : {user['username']}")
        print(f"Repos      : {user['public_repos']}")
        print(f"Followers  : {user['followers']}")
        print(f"Location   : {user['location']}")
        print(f"Profile    : {user['profile_url']}")
    else:
        print(f"Error: {user['error']}")

    # --- Test 2: GitHub Repos ---
    print("\n📌 TEST 2: GitHub Repos")
    print("-" * 40)

    repos = get_github_repos("microsoft", limit=3)
    if isinstance(repos, list):
        for repo in repos:
            print(f"  ⭐ {repo['stars']:>6} | {repo['name']:30} | {repo['language']}")
    else:
        print(repos)

    # --- Test 3: Simulated LLM Call ---
    print("\n📌 TEST 3: Simulated LLM Call (no API key needed)")
    print("-" * 40)

    simulate_llm_call("What is a vector database?")
    simulate_llm_call("Explain RAG in simple terms")

    # --- Test 4: Safe API Call wrapper ---
    print("\n📌 TEST 4: Safe API Call Wrapper")
    print("-" * 40)

    result = safe_api_call("https://api.github.com/users/gvanrossum")
    if result:
        print(f"  Guido van Rossum (Python creator)")
        print(f"  Repos: {result.get('public_repos')}")
        print(f"  Followers: {result.get('followers')}")

    print("\n✅ All tests complete!")
    print("\n💡 TIP: To use real LLM APIs, get a free Groq API key at: https://console.groq.com")
    print("   We'll use Groq in Day 3 when we build the Q&A API project!")
