# ============================================================
# DAY 1 - PART 5: Testing Your FastAPI Server
# AI Engineering Bootcamp - Codebasics
# ============================================================
# WHAT YOU WILL LEARN:
#   - How to test API endpoints with Python
#   - Testing success cases and error cases
#   - Pretty-printing JSON responses
# ============================================================
# HOW TO RUN:
#   STEP 1: Start the server first (in a separate terminal):
#           uvicorn day1_part4_fastapi_server:app --reload
#
#   STEP 2: Run this test file (in another terminal):
#           python day1_part5_test_api.py
# ============================================================

import requests
import json

# Base URL of our running FastAPI server
BASE_URL = "http://127.0.0.1:8000"


def print_result(test_name, response):
    """Helper to pretty-print API test results"""
    print(f"\n{'─' * 50}")
    print(f"  🧪 {test_name}")
    print(f"  Status Code: {response.status_code}")

    # Try to parse and pretty-print JSON
    try:
        data = response.json()
        print(f"  Response:\n{json.dumps(data, indent=4)}")
    except Exception:
        print(f"  Response: {response.text}")


# ============================================================
# TEST 1: Health Check
# ============================================================
print("=" * 55)
print("  Testing AI Engineering Bootcamp API")
print("=" * 55)

response = requests.get(f"{BASE_URL}/health")
print_result("Health Check", response)


# ============================================================
# TEST 2: Root Endpoint
# ============================================================

response = requests.get(f"{BASE_URL}/")
print_result("Root Endpoint", response)


# ============================================================
# TEST 3: Analyze Company - Success Case
# ============================================================
# Sending a POST request with JSON body

apple_data = {
    "name": "Apple",
    "ticker": "AAPL",
    "stock_price": 189.0,
    "shares_outstanding": 15500,   # in millions
    "rd_spend": 29000              # in millions
}

response = requests.post(
    f"{BASE_URL}/company/analyze",
    json=apple_data          # json= automatically sets Content-Type header
)
print_result("Analyze Apple (success)", response)


# ============================================================
# TEST 4: Analyze Company - Without R&D
# ============================================================

tesla_data = {
    "name": "Tesla",
    "ticker": "TSLA",
    "stock_price": 245.0,
    "shares_outstanding": 3190
    # No rd_spend - it's optional
}

response = requests.post(f"{BASE_URL}/company/analyze", json=tesla_data)
print_result("Analyze Tesla (no R&D)", response)


# ============================================================
# TEST 5: Analyze Company - Error Case (invalid data)
# ============================================================

bad_data = {
    "name": "Bad Company",
    "ticker": "BAD",
    "stock_price": -50,     # ← Invalid! Negative price
    "shares_outstanding": 1000
}

response = requests.post(f"{BASE_URL}/company/analyze", json=bad_data)
print_result("Analyze Company (invalid stock price)", response)


# ============================================================
# TEST 6: GitHub Profile - Success
# ============================================================

response = requests.get(f"{BASE_URL}/github/torvalds")
print_result("GitHub Profile - torvalds", response)


# ============================================================
# TEST 7: GitHub Profile - Not Found
# ============================================================

response = requests.get(f"{BASE_URL}/github/this_user_does_not_exist_xyz_123")
print_result("GitHub Profile - Not Found (404)", response)


# ============================================================
# TEST 8: Top Companies - Default (n=3)
# ============================================================

response = requests.get(f"{BASE_URL}/companies/top")
print_result("Top 3 Companies (default)", response)


# ============================================================
# TEST 9: Top Companies - Custom n
# ============================================================

response = requests.get(f"{BASE_URL}/companies/top?n=5")
print_result("Top 5 Companies", response)


# ============================================================
# TEST 10: Top Companies - Invalid n (out of range)
# ============================================================

response = requests.get(f"{BASE_URL}/companies/top?n=100")
print_result("Top Companies - Invalid n=100 (should fail)", response)


# ============================================================
# TEST 11: All Companies
# ============================================================

response = requests.get(f"{BASE_URL}/companies/all")
print_result("All Companies", response)


# ============================================================
# SUMMARY
# ============================================================
print("\n" + "=" * 55)
print("  ✅ All tests complete!")
print("  📖 Visit http://127.0.0.1:8000/docs for interactive docs")
print("=" * 55)
