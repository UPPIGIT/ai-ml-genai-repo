# ============================================================
# DAY 1 - PART 1: Python OOP Basics
# AI Engineering Bootcamp - Codebasics
# ============================================================
# WHAT YOU WILL LEARN:
#   - Classes and Objects
#   - Constructors (__init__)
#   - Instance vs Class variables
#   - Instance methods, Class methods, Static methods
#   - Inheritance and super()
#   - Magic (Dunder) methods
# ============================================================


# ============================================================
# SECTION 1: Basic Class
# ============================================================

class LLMConfig:
    """
    A class to store configuration for an LLM (Large Language Model).
    Think of this like a settings object for ChatGPT or Claude.
    """

    # ---- Class Variable ----
    # Shared across ALL objects of this class
    # Like a global setting for all configs
    provider = "OpenAI"

    # ---- Constructor ----
    # Called automatically when you create an object: LLMConfig(...)
    # 'self' refers to the current object being created
    def __init__(self, model_name, temperature, max_tokens):
        # ---- Instance Variables ----
        # Each object gets its OWN copy of these
        self.model_name = model_name      # e.g. "gpt-4"
        self.temperature = temperature    # 0 = focused, 1 = creative
        self.max_tokens = max_tokens      # max words in response

    # ---- Instance Method ----
    # Regular method that works on a specific object (uses 'self')
    def describe(self):
        return (f"Model: {self.model_name} | "
                f"Temp: {self.temperature} | "
                f"Max Tokens: {self.max_tokens}")

    # ---- Class Method ----
    # Works on the CLASS itself (not an instance)
    # Used here as a "factory" to create a default config
    # 'cls' refers to the class itself
    @classmethod
    def default(cls):
        return cls("gpt-4", 0.7, 1000)   # Creates a new LLMConfig object

    # ---- Static Method ----
    # A utility function that belongs to the class
    # Does NOT need access to the class or any object (no cls or self)
    @staticmethod
    def is_valid_temperature(temp):
        """Temperature must be between 0.0 and 2.0 for OpenAI models"""
        return 0.0 <= temp <= 2.0


# ---- Creating Objects (Instances) ----
config1 = LLMConfig("gpt-4", 0.7, 1000)        # Custom config
config2 = LLMConfig("claude-3", 0.2, 2000)      # Another custom config
config3 = LLMConfig.default()                    # Default config via class method

print("=" * 50)
print("SECTION 1: Basic Class")
print("=" * 50)
print(config1.describe())
print(config2.describe())
print(config3.describe())

# Class variable is same for all objects
print(f"\nProvider for config1: {config1.provider}")
print(f"Provider for config2: {config2.provider}")

# Static method - called on the class, not an object
print(f"\nIs 1.5 a valid temperature? {LLMConfig.is_valid_temperature(1.5)}")
print(f"Is 3.0 a valid temperature? {LLMConfig.is_valid_temperature(3.0)}")


# ============================================================
# SECTION 2: Inheritance
# ============================================================
# Inheritance lets a child class REUSE and EXTEND a parent class
# This is exactly how LangChain works:
#   BaseLanguageModel (parent) -> ChatOpenAI (child)

class BaseModel:
    """
    Parent class - represents any AI model.
    Like LangChain's BaseLLM that all LLMs inherit from.
    """

    def __init__(self, model_name, api_key):
        self.model_name = model_name
        self.api_key = api_key
        self.call_count = 0   # Tracks how many times this model was called

    def invoke(self, prompt):
        """
        Every child MUST implement this method.
        Raising NotImplementedError forces child classes to override it.
        """
        raise NotImplementedError("Subclasses must implement invoke()")

    def get_stats(self):
        return f"Model: {self.model_name} | Calls made: {self.call_count}"


class ChatModel(BaseModel):
    """
    Child class for cloud-based chat models (like GPT-4, Claude).
    Inherits everything from BaseModel, adds temperature support.
    """

    def __init__(self, model_name, api_key, temperature=0.7):
        # super().__init__() calls the PARENT class constructor
        # Always call this first when inheriting!
        super().__init__(model_name, api_key)
        self.temperature = temperature   # Extra property for chat models

    def invoke(self, prompt):
        """Override the parent's invoke() with actual behavior"""
        self.call_count += 1   # Track usage
        # In real life, this would make an HTTP call to OpenAI/Anthropic
        return f"[{self.model_name}] Response to: '{prompt}' (temp={self.temperature})"


class LocalModel(BaseModel):
    """
    Child class for locally running models (like Llama via Ollama).
    No API key needed - runs on your own machine.
    """

    def __init__(self, model_name, model_path):
        # Pass None as api_key since local models don't need one
        super().__init__(model_name, api_key=None)
        self.model_path = model_path   # Where the model file is stored

    def invoke(self, prompt):
        """Local models process differently - no API call needed"""
        self.call_count += 1
        return f"[LOCAL: {self.model_name}] Processing: '{prompt}'"

    def get_stats(self):
        """
        Override parent's get_stats() to ADD extra info.
        We call super().get_stats() to keep the parent's output
        and just add more to it.
        """
        base_stats = super().get_stats()   # Get parent's stats string
        return f"{base_stats} | Path: {self.model_path}"


print("\n" + "=" * 50)
print("SECTION 2: Inheritance")
print("=" * 50)

chat = ChatModel("gpt-4", "sk-abc123", temperature=0.5)
local = LocalModel("llama-3", "/models/llama")

print(chat.invoke("What is RAG?"))
print(local.invoke("Explain embeddings"))
print(chat.get_stats())    # Uses BaseModel's get_stats()
print(local.get_stats())   # Uses LocalModel's overridden get_stats()


# ============================================================
# SECTION 3: Magic (Dunder) Methods
# ============================================================
# These are special methods with double underscores: __str__, __len__, etc.
# They let your objects work with Python built-in functions and operators.

class TokenBudget:
    """
    Tracks token usage for an LLM session.
    
    Tokens are units of text - roughly 1 token ≈ 0.75 words.
    LLMs charge per token, so tracking this is very important!
    """

    def __init__(self, max_tokens):
        self.max_tokens = max_tokens
        self.used_tokens = 0
        self.history = []   # List of (label, tokens) tuples

    def use(self, tokens, label="call"):
        """Record token usage for a specific operation"""
        if self.used_tokens + tokens > self.max_tokens:
            raise ValueError(
                f"Exceeds budget! "
                f"Used: {self.used_tokens}, "
                f"Requested: {tokens}, "
                f"Max: {self.max_tokens}"
            )
        self.used_tokens += tokens
        self.history.append((label, tokens))

    # __str__: Called when you do print(object) or str(object)
    # Should return a human-friendly description
    def __str__(self):
        remaining = self.max_tokens - self.used_tokens
        return (f"TokenBudget: {self.used_tokens}/{self.max_tokens} used "
                f"({remaining} remaining)")

    # __repr__: Called in the Python console or repr(object)
    # Should return a developer-friendly description (how to recreate the object)
    def __repr__(self):
        return f"TokenBudget(max={self.max_tokens}, used={self.used_tokens})"

    # __len__: Called when you do len(object)
    def __len__(self):
        return self.used_tokens

    # __contains__: Called when you do "something" in object
    def __contains__(self, label):
        return any(h[0] == label for h in self.history)

    # __add__: Called when you do object1 + object2
    def __add__(self, other):
        combined = TokenBudget(self.max_tokens + other.max_tokens)
        combined.used_tokens = self.used_tokens + other.used_tokens
        return combined


print("\n" + "=" * 50)
print("SECTION 3: Magic Methods")
print("=" * 50)

budget = TokenBudget(10000)
budget.use(1500, "system_prompt")
budget.use(350, "user_query")
budget.use(820, "llm_response")

print(budget)                          # Calls __str__
print(repr(budget))                    # Calls __repr__
print(f"Tokens used: {len(budget)}")   # Calls __len__
print(f"'user_query' used? {'user_query' in budget}")    # Calls __contains__
print(f"'image_call' used? {'image_call' in budget}")    # False

budget2 = TokenBudget(5000)
budget2.use(1000, "other_call")
combined = budget + budget2            # Calls __add__
print(f"Combined budget: {combined}")
