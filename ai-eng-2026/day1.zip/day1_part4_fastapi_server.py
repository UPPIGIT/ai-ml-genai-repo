# ============================================================
# DAY 1 - PART 4: Building a FastAPI Server
# AI Engineering Bootcamp - Codebasics
# ============================================================
# WHAT YOU WILL LEARN:
#   - What FastAPI is and why it's the #1 choice for AI backends
#   - Defining API routes (GET, POST)
#   - Request/Response validation with Pydantic
#   - Path parameters vs Query parameters
#   - Error handling with HTTPException
#   - Auto-generated API documentation
# ============================================================
# HOW TO RUN:
#   pip install fastapi uvicorn requests
#   uvicorn day1_part4_fastapi_server:app --reload
#
#   Then open your browser:
#   http://127.0.0.1:8000          → Root endpoint
#   http://127.0.0.1:8000/docs     → Interactive API docs (Swagger UI)
#   http://127.0.0.1:8000/redoc    → Alternative docs (ReDoc)
# ============================================================

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from typing import Optional, List
import requests

# ============================================================
# CREATE THE FASTAPI APP
# ============================================================
# FastAPI() creates your web application.
# title, description, version appear in the auto-generated docs.

app = FastAPI(
    title="AI Engineering Bootcamp API",
    description="Day 1 project: Market Cap Calculator + GitHub Analyzer",
    version="1.0.0"
)

# ============================================================
# PYDANTIC MODELS (Request & Response Schemas)
# ============================================================
# Pydantic models do TWO things:
#   1. VALIDATE incoming data (e.g. ensure stock_price is a number)
#   2. DOCUMENT your API (auto-shown in Swagger UI)
#
# Think of them as "contracts" for your API:
# "If you call this endpoint, send data in THIS shape"

class CompanyRequest(BaseModel):
    """
    Data we RECEIVE from the user when they call POST /company/analyze
    FastAPI automatically validates this before your function even runs.
    """
    name: str = Field(..., example="Apple", description="Company name")
    ticker: str = Field(..., example="AAPL", description="Stock ticker symbol")
    stock_price: float = Field(..., example=189.0, description="Current stock price in USD")
    shares_outstanding: float = Field(..., example=15500.0, description="Shares outstanding in millions")
    rd_spend: Optional[float] = Field(None, example=29000.0, description="R&D spend in millions (optional)")

    # ... means "required" (no default value)
    # Optional[float] means it can be float or None


class CompanyResponse(BaseModel):
    """
    Data we SEND BACK to the user after processing.
    """
    name: str
    ticker: str
    market_cap_millions: float
    market_cap_label: str
    rd_ratio: Optional[float] = None  # Will be None if rd_spend wasn't provided


class GitHubProfile(BaseModel):
    """Response model for GitHub user profile"""
    name: Optional[str]
    username: str
    public_repos: int
    followers: int
    bio: Optional[str]
    location: Optional[str]
    profile_url: str


class CompanyListItem(BaseModel):
    """One item in the companies list"""
    name: str
    ticker: str
    market_cap: str
    rank: int


# ============================================================
# HARDCODED DATA (In real apps, this would come from a database)
# ============================================================

TECH_COMPANIES_DATA = [
    {"name": "Apple",     "ticker": "AAPL", "price": 189, "shares": 15500, "rd": 29000},
    {"name": "Microsoft", "ticker": "MSFT", "price": 378, "shares": 7430,  "rd": 27000},
    {"name": "Google",    "ticker": "GOOGL", "price": 141, "shares": 12500, "rd": 45000},
    {"name": "Amazon",    "ticker": "AMZN", "price": 178, "shares": 10500, "rd": 85000},
    {"name": "NVIDIA",    "ticker": "NVDA", "price": 875, "shares": 2460,  "rd": 8900},
    {"name": "Meta",      "ticker": "META", "price": 485, "shares": 2580,  "rd": 35000},
    {"name": "Tesla",     "ticker": "TSLA", "price": 245, "shares": 3190,  "rd": 3200},
]


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def format_market_cap(cap_millions: float) -> str:
    """Format a number in millions into a human-readable string"""
    if cap_millions >= 1_000_000:
        return f"${cap_millions / 1_000_000:.2f}T"
    elif cap_millions >= 1_000:
        return f"${cap_millions / 1_000:.2f}B"
    return f"${cap_millions:.2f}M"


def calculate_market_cap(price: float, shares_millions: float) -> float:
    """Calculate market cap in millions"""
    return price * shares_millions


# ============================================================
# ROUTES (API Endpoints)
# ============================================================
# Each route is a URL that users can call.
# The decorator (@app.get, @app.post) defines:
#   - The HTTP method (GET or POST)
#   - The URL path

# ---- Route 1: Root ----
@app.get("/")
def root():
    """
    The home page of your API.
    Called when someone visits http://127.0.0.1:8000/
    """
    return {
        "message": "Welcome to AI Engineering Bootcamp API!",
        "version": "1.0.0",
        "docs": "Visit /docs for interactive API documentation"
    }


# ---- Route 2: Health Check ----
@app.get("/health")
def health_check():
    """
    Used by monitoring tools (like AWS) to check if your server is alive.
    If this returns 200, the server is healthy.
    """
    return {"status": "healthy", "uptime": "running"}


# ---- Route 3: Analyze Company (POST) ----
@app.post("/company/analyze", response_model=CompanyResponse)
def analyze_company(company: CompanyRequest):
    """
    Calculate market cap and R&D ratio for a company.

    POST because we're SENDING data to the server for processing.

    FastAPI automatically:
    1. Parses the JSON body
    2. Validates it against CompanyRequest
    3. Returns a 422 error if data is invalid
    """

    # --- Validation (business logic) ---
    # FastAPI handles type validation, but we handle business rules here
    if company.stock_price <= 0:
        # HTTPException sends an error response with a status code
        # 400 = Bad Request (the client sent invalid data)
        raise HTTPException(
            status_code=400,
            detail="Stock price must be a positive number"
        )

    if company.shares_outstanding <= 0:
        raise HTTPException(
            status_code=400,
            detail="Shares outstanding must be a positive number"
        )

    # --- Calculation ---
    market_cap = calculate_market_cap(company.stock_price, company.shares_outstanding)

    rd_ratio = None
    if company.rd_spend is not None:
        rd_ratio = round((company.rd_spend / market_cap) * 100, 4)

    # --- Return Response ---
    # FastAPI validates this against CompanyResponse before sending
    return CompanyResponse(
        name=company.name,
        ticker=company.ticker.upper(),   # Ensure ticker is uppercase
        market_cap_millions=round(market_cap, 2),
        market_cap_label=format_market_cap(market_cap),
        rd_ratio=rd_ratio
    )


# ---- Route 4: GitHub Profile (Path Parameter) ----
@app.get("/github/{username}", response_model=GitHubProfile)
def get_github_profile(username: str):
    """
    Fetch a GitHub user's public profile.

    {username} is a PATH PARAMETER - it's part of the URL itself.
    Example: GET /github/torvalds  →  username = "torvalds"
    """

    # Call GitHub's API
    response = requests.get(
        f"https://api.github.com/users/{username}",
        timeout=10
    )

    # Handle different error cases
    if response.status_code == 404:
        raise HTTPException(
            status_code=404,   # Forward the 404
            detail=f"GitHub user '{username}' not found"
        )

    if response.status_code != 200:
        raise HTTPException(
            status_code=502,   # 502 = Bad Gateway (upstream API failed)
            detail=f"GitHub API returned {response.status_code}"
        )

    data = response.json()

    return GitHubProfile(
        name=data.get("name"),
        username=data.get("login"),
        public_repos=data.get("public_repos", 0),
        followers=data.get("followers", 0),
        bio=data.get("bio"),
        location=data.get("location"),
        profile_url=data.get("html_url")
    )


# ---- Route 5: Top Companies (Query Parameter) ----
@app.get("/companies/top")
def get_top_companies(
    n: int = Query(default=3, ge=1, le=7, description="Number of companies to return")
):
    """
    Return top N tech companies by market cap.

    n is a QUERY PARAMETER - it's added at the end of the URL:
    /companies/top?n=5  →  n = 5
    /companies/top      →  n = 3 (default)

    Query() adds validation:
    - default=3: use 3 if not provided
    - ge=1: must be >= 1
    - le=7: must be <= 7 (we only have 7 companies)
    """

    # Calculate market cap for each company
    companies_with_cap = []
    for c in TECH_COMPANIES_DATA:
        cap = calculate_market_cap(c["price"], c["shares"])
        companies_with_cap.append({
            "name": c["name"],
            "ticker": c["ticker"],
            "cap": cap,
            "cap_label": format_market_cap(cap)
        })

    # Sort by market cap (highest first) and take top n
    sorted_companies = sorted(companies_with_cap, key=lambda x: x["cap"], reverse=True)[:n]

    # Build response
    result = []
    for rank, company in enumerate(sorted_companies, start=1):
        result.append({
            "rank": rank,
            "name": company["name"],
            "ticker": company["ticker"],
            "market_cap": company["cap_label"]
        })

    return {
        "count": len(result),
        "companies": result
    }


# ---- Route 6: Compare All Companies ----
@app.get("/companies/all")
def get_all_companies():
    """
    Return all tech companies with their market cap info.
    Sorted from highest to lowest market cap.
    """

    result = []
    for c in TECH_COMPANIES_DATA:
        cap = calculate_market_cap(c["price"], c["shares"])
        rd_ratio = round((c["rd"] / cap) * 100, 4) if c.get("rd") else None

        result.append({
            "name": c["name"],
            "ticker": c["ticker"],
            "stock_price": f"${c['price']}",
            "market_cap": format_market_cap(cap),
            "market_cap_millions": cap,
            "rd_ratio_percent": rd_ratio
        })

    # Sort by market cap
    result.sort(key=lambda x: x["market_cap_millions"], reverse=True)

    # Add rank after sorting
    for i, company in enumerate(result, start=1):
        company["rank"] = i
        del company["market_cap_millions"]  # Remove raw number, keep formatted

    return {
        "count": len(result),
        "total_market_cap": format_market_cap(
            sum(calculate_market_cap(c["price"], c["shares"]) for c in TECH_COMPANIES_DATA)
        ),
        "companies": result
    }


# ============================================================
# HOW TO RUN THIS SERVER
# ============================================================
# Open terminal and run:
#     uvicorn day1_part4_fastapi_server:app --reload
#
# --reload means: auto-restart when you save changes (great for development)
#
# Then visit:
#   http://127.0.0.1:8000/docs       ← TRY THIS! Beautiful interactive docs
#   http://127.0.0.1:8000/companies/top?n=5
#   http://127.0.0.1:8000/github/torvalds
